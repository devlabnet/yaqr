# Yaqr
@DevLabNet :+1: This Widget is great - it's Time to Test It! 

Yet Another QR Widget
This widget is designed to easily create QR-Code Link Image.

The code generation is based on a slighty modified javascript code from Kazuhiko Arase. Many Thanks to Him for is work.

You can easily edit the QR Image (Size, Border Color and width, Background and Points colors ...) 

The QR-Code image is also clickable ("href") to go tho the image Link.
